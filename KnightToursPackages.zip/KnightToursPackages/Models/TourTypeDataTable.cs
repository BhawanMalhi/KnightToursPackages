﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace KnightToursPackages.Models
{
    public class TourTypeDataTable
    {
        public int To_ID { get; set; }
        public string To_Type { get; set; }
        public int To_Price { get; set; }
        public string To_Place { get; set; }
        public string To_Method { get; set; }

    }
}